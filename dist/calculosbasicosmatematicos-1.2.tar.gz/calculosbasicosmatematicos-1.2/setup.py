from setuptools import setup
setup(
    name="calculosbasicosmatematicos",
    version="1.2",
    description="Segunda parte",
    author="Dani",
    author_mail="zatak631979@gmail.com",
    url="",
    packages=["moduloMatematico", "modulomatematico.calculosBasicos"]










)